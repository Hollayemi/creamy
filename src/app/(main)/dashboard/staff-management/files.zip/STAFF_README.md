# Staff Management System - Complete Documentation

## 📋 Overview

A comprehensive staff/user management system with role-based access control, activity logging, and account management features for your e-commerce dashboard.

## 🎯 Features

### Core Features
- ✅ **Staff CRUD Operations** - Create, view, edit, and delete staff members
- ✅ **Role & Permission Management** - Assign roles and customize permissions
- ✅ **Activity Logging** - Track all user actions with detailed logs
- ✅ **Account Actions**:
  - Reset Password (with email notification)
  - Suspend Account (temporary block)
  - Disable Account (permanent revocation)
- ✅ **Search & Filter** - Search by name/email, filter by status
- ✅ **Bulk Operations** - Select multiple staff for batch actions
- ✅ **Export Data** - Export staff list to CSV/Excel
- ✅ **Pagination** - Efficient data loading with pagination

### Security Features
- Password reset with temporary passwords
- Email notifications for account changes
- Activity audit trail
- Session management
- Permission-based access control

## 📦 Files Included (10 files)

### API Service
1. **staffApi.ts** - Complete RTK Query API service
   - Staff CRUD endpoints
   - Role & permission endpoints
   - Activity logs endpoints
   - Account action endpoints (suspend, disable, reset password)
   - Bulk operations
   - Export functionality

### Main Component
2. **staff-management-page.tsx** - Main dashboard page
   - Staff table with search and filters
   - Dropdown actions menu
   - Pagination controls
   - Bulk selection

### Dialog Components
3. **create-staff-dialog.tsx** - Multi-step staff creation
   - Basic information form
   - Role assignment
   - Permission selection (manual or role-based)

4. **edit-staff-dialog.tsx** - Edit role and permissions
   - Role selection
   - Custom permission overrides
   - Visual permission list

5. **activity-logs-drawer.tsx** - Activity timeline view
   - Chronological activity list
   - Color-coded action types
   - Metadata display

6. **reset-password-dialog.tsx** - Password reset flow
   - Email notification option
   - Temporary password display
   - Copy to clipboard

7. **suspend-account-dialog.tsx** - Temporary suspension
   - Reason input (required)
   - Email notification option
   - Warning messages

8. **disable-account-dialog.tsx** - Permanent disablement
   - Reason input (required)
   - Email notification option
   - Strong warning messages

### Configuration
9. **baseApi.ts** - Updated with staff tags
10. **STAFF_README.md** - This documentation file

## 🚀 Installation

### 1. Install Dependencies

```bash
# If not already installed
npm install @reduxjs/toolkit react-redux axios date-fns
npm install lucide-react sonner
```

### 2. Install Additional shadcn/ui Components

```bash
npx shadcn-ui@latest add checkbox
npx shadcn-ui@latest add avatar
npx shadcn-ui@latest add dropdown-menu
npx shadcn-ui@latest add sheet
npx shadcn-ui@latest add scroll-area
```

### 3. File Structure

```
src/
├── stores/
│   └── services/
│       ├── baseApi.ts (updated)
│       ├── staffApi.ts
│       └── api/
│           └── types.ts
├── components/
│   └── staff/
│       ├── staff-management-page.tsx
│       ├── create-staff-dialog.tsx
│       ├── edit-staff-dialog.tsx
│       ├── activity-logs-drawer.tsx
│       ├── reset-password-dialog.tsx
│       ├── suspend-account-dialog.tsx
│       └── disable-account-dialog.tsx
└── app/
    └── dashboard/
        └── staff/
            └── page.tsx
```

### 4. Create the Route

```typescript
// app/dashboard/staff/page.tsx
import StaffManagementPage from "@/components/staff/staff-management-page";

export default function StaffPage() {
  return <StaffManagementPage />;
}

export const metadata = {
  title: "Staff Management | Dashboard",
  description: "Manage team members and permissions",
};
```

## 🔌 API Endpoints

### Staff Endpoints
```
GET    /api/v1/staff                    # Get all staff (with filters)
GET    /api/v1/staff/:id                # Get staff by ID
POST   /api/v1/staff                    # Create new staff
PUT    /api/v1/staff/:id                # Update staff
DELETE /api/v1/staff/:id                # Delete staff
```

### Account Actions
```
POST   /api/v1/staff/:id/suspend        # Suspend account
POST   /api/v1/staff/:id/unsuspend      # Unsuspend account
POST   /api/v1/staff/:id/disable        # Disable account
POST   /api/v1/staff/:id/enable         # Enable account
POST   /api/v1/staff/:id/reset-password # Reset password
PUT    /api/v1/staff/:id/role           # Update role/permissions
```

### Roles & Permissions
```
GET    /api/v1/roles                    # Get all roles
GET    /api/v1/roles/:id                # Get role by ID
GET    /api/v1/permissions              # Get all permissions
```

### Activity Logs
```
GET    /api/v1/activity-logs            # Get all logs (filtered)
GET    /api/v1/staff/:id/activity-logs  # Get user's logs
```

### Bulk Operations
```
POST   /api/v1/staff/bulk/suspend       # Suspend multiple
DELETE /api/v1/staff/bulk/delete        # Delete multiple
```

### Export
```
POST   /api/v1/staff/export/csv         # Export as CSV
POST   /api/v1/staff/export/excel       # Export as Excel
```

## 📊 Data Models

### Staff Model
```typescript
interface Staff {
  _id: string;
  fullName: string;
  email: string;
  role: string;              // Role ID
  roleName?: string;         // Role display name
  region?: string;
  branch?: string;
  status: "active" | "suspended" | "disabled" | "running";
  joinedDate: string;
  lastLogin?: string;
  avatar?: string;
  phone?: string;
  createdAt: string;
  updatedAt: string;
}
```

### Role Model
```typescript
interface Role {
  _id: string;
  name: string;
  displayName: string;
  permissions: string[];     // Array of permission IDs
  createdAt: string;
  updatedAt: string;
}
```

### Permission Model
```typescript
interface Permission {
  id: string;
  name: string;
  description: string;
}
```

### Activity Log Model
```typescript
interface ActivityLog {
  _id: string;
  userId: string;
  userName: string;
  action: string;
  description: string;
  metadata?: Record<string, any>;
  timestamp: string;
  ipAddress?: string;
}
```

## 🎨 Features in Detail

### 1. Create New Staff

**Two-Step Process:**

**Step 1 - Basic Information:**
- Full name
- Email address
- Phone number
- Temporary password
- Region assignment
- Branch assignment
- Role selection
- Option to manually select permissions

**Step 2 - Permissions (if manual selected):**
- View all available permissions
- See permissions from selected role (auto-checked, disabled)
- Add additional custom permissions
- Option to revert to role defaults

### 2. Edit Role & Permissions

- Change staff member's role
- Add custom permissions on top of role permissions
- Visual indication of permissions from role vs custom
- Save changes with validation

### 3. View Activity Logs

**Timeline View:**
- Color-coded activity types
- Chronological order (newest first)
- Detailed descriptions
- Metadata expansion
- Timestamp for each activity

**Activity Types:**
- Login/Logout
- Created/Updated/Deleted items
- Approved/Cancelled orders
- Suspended/Disabled accounts
- Role changes

### 4. Reset Password

**Process:**
- Confirm action with warning
- Option to notify user by email
- Generate secure temporary password
- Display password (if not emailed)
- Copy to clipboard feature
- User must change on next login

### 5. Suspend Account

**Temporary Action:**
- Require reason (mandatory)
- Optional email notification
- Immediate logout
- Terminate all sessions
- Can be reversed
- Logged for audit

### 6. Disable Account

**Permanent Action:**
- Require reason (mandatory)
- Optional email notification
- Strong warning messages
- Immediate logout
- Revoke all permissions
- Can be re-enabled by admin
- Permanently logged

## 🔒 Security Best Practices

### 1. Password Security
```typescript
// Backend should:
- Hash passwords with bcrypt
- Validate password strength
- Force password change on first login
- Implement password expiry
```

### 2. Session Management
```typescript
// When suspending/disabling:
- Invalidate all JWT tokens
- Clear Redis sessions
- Log out from all devices
```

### 3. Audit Trail
```typescript
// Log all critical actions:
- Staff creation/deletion
- Role/permission changes
- Password resets
- Account suspensions/disablements
- Login attempts
```

### 4. Permission Checks
```typescript
// Implement middleware:
- Check user has required permission
- Validate role before action
- Log unauthorized attempts
```

## 🎯 Usage Examples

### Basic Usage

```typescript
// Import and use in your route
import StaffManagementPage from "@/components/staff/staff-management-page";

export default function Page() {
  return <StaffManagementPage />;
}
```

### Using Individual Components

```typescript
// Create Staff Dialog standalone
import CreateStaffDialog from "@/components/staff/create-staff-dialog";

function MyComponent() {
  const [open, setOpen] = useState(false);
  
  return (
    <>
      <Button onClick={() => setOpen(true)}>Add Staff</Button>
      <CreateStaffDialog open={open} onOpenChange={setOpen} />
    </>
  );
}
```

### Using API Hooks

```typescript
// Get all staff
const { data, isLoading } = useGetAllStaffQuery({
  search: "john",
  status: "active",
  page: 1,
  limit: 10,
});

// Create staff
const [createStaff, { isLoading }] = useCreateStaffMutation();
await createStaff({
  fullName: "John Doe",
  email: "john@example.com",
  password: "temp123",
  role: "roleId",
}).unwrap();

// Reset password
const [resetPassword] = useResetPasswordMutation();
await resetPassword({
  id: staffId,
  notifyUser: true,
}).unwrap();
```

## 🎨 Customization

### 1. Status Badge Colors

```typescript
// Modify in staff-management-page.tsx
const getStatusBadge = (status: string) => {
  const variants = {
    active: { variant: "default", label: "Active" },
    suspended: { variant: "warning", label: "Suspended" },
    disabled: { variant: "destructive", label: "Disabled" },
    // Add custom statuses
    probation: { variant: "secondary", label: "Probation" },
  };
  // ...
};
```

### 2. Activity Log Colors

```typescript
// Modify in activity-logs-drawer.tsx
const getActivityIcon = (action: string) => {
  const colors = {
    login: "bg-green-100 text-green-600",
    create: "bg-blue-100 text-blue-600",
    // Add custom action colors
    approved: "bg-purple-100 text-purple-600",
  };
  // ...
};
```

### 3. Add Custom Fields

```typescript
// In create-staff-dialog.tsx, add new field:
<div className="space-y-2">
  <Label htmlFor="department">Department</Label>
  <Input
    id="department"
    value={formData.department}
    onChange={(e) => setFormData({ ...formData, department: e.target.value })}
  />
</div>
```

## 🐛 Troubleshooting

### Common Issues

**1. "Cannot read properties of undefined"**
```typescript
// Ensure data exists before rendering
const staff = staffResponse?.data || [];
```

**2. Permissions not loading**
```typescript
// Check API is injected properly
export const staffApi = baseApi.injectEndpoints({
  // ...
});
```

**3. Activity logs not showing**
```typescript
// Verify skip parameter
const { data } = useGetUserActivityLogsQuery(userId, {
  skip: !open, // Only fetch when drawer is open
});
```

**4. Dialog not closing after action**
```typescript
// Ensure onOpenChange is called
toast.success("Action completed");
onOpenChange(false); // Close dialog
```

## 📈 Performance Optimization

### 1. Lazy Loading Dialogs

```typescript
import dynamic from "next/dynamic";

const CreateStaffDialog = dynamic(() => import("./create-staff-dialog"));
```

### 2. Debounce Search

```typescript
import { useDebouncedCallback } from "use-debounce";

const debouncedSearch = useDebouncedCallback(
  (value) => setSearchQuery(value),
  300
);
```

### 3. Virtual Scrolling for Large Lists

```typescript
import { useVirtualizer } from "@tanstack/react-virtual";
// Implement virtual scrolling for 1000+ staff members
```

## 🧪 Testing Recommendations

### Unit Tests
- Test form validation
- Test permission toggle logic
- Test status badge rendering

### Integration Tests
- Test API calls
- Test dialog flows
- Test bulk operations

### E2E Tests
- Test complete staff creation flow
- Test password reset flow
- Test suspension/disablement

## 🔮 Future Enhancements

Potential features to add:

- [ ] Import staff from CSV
- [ ] Bulk role assignment
- [ ] Staff groups/teams
- [ ] Custom permission creation
- [ ] Email template customization
- [ ] Multi-factor authentication
- [ ] Session history
- [ ] Login location tracking
- [ ] Password policy configuration
- [ ] Account recovery workflow

## 📝 License

MIT License - Free to use in your projects

---

**Need Help?** Check the troubleshooting section or review the inline comments in the code files.
