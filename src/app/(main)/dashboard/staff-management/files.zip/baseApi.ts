import { createApi } from "@reduxjs/toolkit/query/react";
import axios, { AxiosRequestConfig } from "axios";
import type { BaseQueryFn } from "@reduxjs/toolkit/query";

// Axios base query function
const axiosBaseQuery =
  (
    { baseUrl }: { baseUrl: string } = { baseUrl: "" }
  ): BaseQueryFn<
    {
      url: string;
      method?: AxiosRequestConfig["method"];
      data?: AxiosRequestConfig["data"];
      params?: AxiosRequestConfig["params"];
      headers?: AxiosRequestConfig["headers"];
      isFormData?: boolean;
    },
    unknown,
    unknown
  > =>
  async ({ url, method = "GET", data, params, headers, isFormData = false }) => {
    try {
      const config: AxiosRequestConfig = {
        url: baseUrl + url,
        method,
        data,
        params,
        headers: {
          ...headers,
          ...(isFormData ? {} : { "Content-Type": "application/json" }),
        },
      };

      const result = await axios(config);
      return { data: result.data };
    } catch (axiosError: any) {
      return {
        error: {
          status: axiosError.response?.status,
          data: axiosError.response?.data || axiosError.message,
        },
      };
    }
  };

// Create base API
export const baseApi = createApi({
  baseQuery: axiosBaseQuery({
    baseUrl: process.env.NEXT_PUBLIC_API_URL || "http://localhost:5000/api/v1",
  }),
  tagTypes: [
    "Categories",
    "Regions", 
    "Deals",
    "Adverts",
    "Products",
    "Orders",
    "Users",
    "Analytics",
    "Staff",
    "Roles",
    "Permissions",
    "ActivityLogs",
  ],
  endpoints: () => ({}),
});

// Export hooks
export const {} = baseApi;
